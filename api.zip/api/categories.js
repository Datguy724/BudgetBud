const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

export const getCategories = async (token) => {
  const res = await fetch(`${API_BASE_URL}/categories`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.json();
};

export const createCategory = async (name, token) => {
  const res = await fetch(`${API_BASE_URL}/categories`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ name })
  });
  return res.json();
};

export const updateCategory = async (id, name, token) => {
  const res = await fetch(`${API_BASE_URL}/categories/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ name })
  });
  return res.json();
};

export const deleteCategory = async (id, token) => {
  const res = await fetch(`${API_BASE_URL}/categories/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.json();
};
